package com.radovan.demo.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class FormInformation {

	@Size(min = 2, max = 15, message = "Minimum 2 and maximum 15 letters!")
	private String firstName;

	@Size(min = 3, max = 15, message = "Minimum 3 and maximum 15 letters!")
	private String lastName;

	@NotEmpty(message = "Gender is required!")
	private String gender;

	private String country;

	@NotEmpty(message = "Message is required!")
	private String message;

	private List<String> programmingSkills;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getProgrammingSkills() {
		return programmingSkills;
	}

	public void setProgrammingSkills(List<String> programmingSkills) {
		this.programmingSkills = programmingSkills;
	}

}
