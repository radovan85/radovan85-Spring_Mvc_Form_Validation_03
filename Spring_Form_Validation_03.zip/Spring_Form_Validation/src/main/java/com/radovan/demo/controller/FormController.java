package com.radovan.demo.controller;

import java.util.LinkedHashMap;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.radovan.demo.model.FormInformation;

@Controller
public class FormController {

	@RequestMapping(value = "/",method = RequestMethod.GET)
	String indexPage(ModelMap map) {
		FormInformation information = new FormInformation();
		
		LinkedHashMap<String, String> gender = 
				new LinkedHashMap<String, String>();
		
		gender.put("female", "female");
		gender.put("male", "male");
		
		map.put("gender", gender);
		map.put("information", information);
		return "index";
	}
	
	@RequestMapping(value = "/welcome",method = RequestMethod.POST)
	String welcomePage(@Validated 
			@ModelAttribute("information") FormInformation info,
			Errors errors,ModelMap map) {
		
		map.put("firstName", info.getFirstName());
		map.put("lastName", info.getLastName());
		map.put("gender", info.getGender());
		map.put("country", info.getCountry());
		map.put("message", info.getMessage());
		map.put("programmingSkills", info.getProgrammingSkills());
		
		if(errors.hasErrors()) {
			System.out.println("Errors are detected!");
			
			LinkedHashMap<String, String> gender = 
					new LinkedHashMap<String, String>();
			
			gender.put("female", "female");
			gender.put("male", "male");
			
			map.put("gender", gender);
			return "index";
		}
		
		System.out.println("Entry is completed!");
		return "welcome";
	}
}
