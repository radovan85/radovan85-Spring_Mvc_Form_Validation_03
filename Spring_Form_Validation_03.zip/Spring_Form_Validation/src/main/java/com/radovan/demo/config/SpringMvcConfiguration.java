package com.radovan.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.radovan.demo")
public class SpringMvcConfiguration implements WebMvcConfigurer{

	@Bean
	public InternalResourceViewResolver getViewResolver() {
		
		InternalResourceViewResolver returnValue = 
				new InternalResourceViewResolver();
		
		returnValue.setPrefix("/WEB-INF/views/");
		returnValue.setSuffix(".jsp");
		return returnValue;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		
		registry.addResourceHandler("/resources/**").
		addResourceLocations("classpath:/statics/","/resources/statics/");
	}
}
